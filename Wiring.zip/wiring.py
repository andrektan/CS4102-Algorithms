def makeSet(name):
    parent[name] = name
    rank[name] = 0
    return


def find(name):
    if name != parent[name]:
        parent[name] = find(parent[name])
    return parent[name]


def union(name1, name2):
    link(find(name1), find(name2))
    return


def link(name1, name2):
    if rank[name1] > rank[name2]:
        parent[name2] = name1
    else:
        parent[name1] = name2
        if rank[name1] == rank[name2]:
            rank[name2] += 1


def kruskal():
    wires_accepted = 0
    mincost = 0
    for i in j_costs:
        # print(i)
        valid = True
        """if junctions[i[0]] == 'light' or junctions[i[1]] == 'light':
            if junctions[i[0]] == 'light':
                if junctions[i[1]] == 'light':
                    if switch_dep[i[0]] != switch_dep[i[1]]:
                        valid = False
                elif junctions[i[1]] == 'switch':
                    if switch_dep[i[0]] != junctions[i[1]]:
                        valid = False
            elif junctions[i[1]] == 'light':
                if junctions[i[0]] == 'light':
                    if switch_dep[i[0]] != switch_dep[i[1]]:
                        valid = False
                elif junctions[i[0]] == 'switch':
                    if switch_dep[i[1]] != junctions[i[0]]:
                        valid = False"""
        if junctions[i[0]] == 'switch' or junctions[i[1]] == 'switch':
            if junctions[i[0]] == 'switch' and junctions[i[1]] != 'light':
                if switch_cons[i[0]] != None:
                    valid = False
                else:
                    switch_cons[i[0]] = i[1]
            elif junctions[i[1]] == 'switch' and junctions[i[0]] != 'light':
                if switch_cons[i[1]] != None:
                    valid = False
                else:
                    switch_cons[i[1]] = i[0]
        if valid == True:
            set1 = find(i[0])
            set2 = find(i[1])
            if set1 != set2:
                wires_accepted += 1
                mincost += int(i[2])
                union(set1, set2)
                #print(str(i) + " accepted")
            # print(wires_accepted)
        if wires_accepted >= len(junctions):
            break
    return mincost


# inputs
j, c = input().split()
j = int(j)
c = int(c)

junctions = {}
j_costs = []
ls_costs = []

num_vertices = 0

parent = {}
rank = {}

switch = ''
switch_dep = {}
switch_cons = {}

for i in range(j):
    junc = input().split()
    if junc[1] == 'light' or junc[1] == 'switch':
        junctions[junc[0]] = junc[1]
        if junc[1] == 'switch':
            switch = junc[0]
            switch_cons[switch] = None
        elif junc[1] == 'light':
            switch_dep[junc[0]] = switch
    else:
        junctions[junc[0]] = junc[1]
    makeSet(junc[0])
    num_vertices += 1


for i in range(c):
    x, y, z = input().split()
    z = int(z)
    junc = [x, y, z]
    if junctions[junc[0]] == 'light':
        if junctions[junc[1]] == 'switch':
            if switch_dep[junc[0]] == junc[1]:
                ls_costs.append(junc)
        elif junctions[junc[1]] == 'light':
            if switch_dep[junc[0]] == switch_dep[junc[1]]:
                ls_costs.append(junc)
        else:
            pass
    elif junctions[junc[1]] == 'light':
        if junctions[junc[0]] == 'switch':
            if switch_dep[junc[1]] == junc[0]:
                ls_costs.append(junc)
        elif junctions[junc[0]] == 'light':
            if switch_dep[junc[0]] == switch_dep[junc[1]]:
                ls_costs.apppend(junc)
        else:
            pass
    elif junctions[junc[0]] == 'switch' and junctions[junc[1]] == 'switch':
        pass
    else:
        j_costs.append(junc)


j_costs.sort(key=lambda x: x[2])
ls_costs.sort(key=lambda x: x[2])
j_costs = ls_costs + j_costs

print(kruskal())
