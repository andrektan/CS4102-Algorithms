def BFS(graph, s, t, parent):
    visited = [False] * len(graph)
    queue = []
    queue.append(s)
    visited[s] = True

    while queue:
        u = queue.pop(0)
        for i in range(len(graph[u])):
            if visited[i] == False and graph[u][i] > 0:
                queue.append(i)
                visited[i] = True
                parent[i] = u
                if i == t:
                    return True

    return False


def FordFulkerson(graph, source, sink):

    parent = [-1] * (len(graph))
    max_flow = 0

    while BFS(graph, source, sink, parent):
        path_flow = float("Inf")
        s = sink
        while(s != source):
            path_flow = min(path_flow, graph[parent[s]][s])
            s = parent[s]

        max_flow += path_flow
        v = sink
        while(v != source):
            u = parent[v]
            graph[u][v] -= path_flow
            graph[v][u] += path_flow
            v = parent[v]

    return max_flow


while True:
    line = input()
    if line == '':
        line = input()
    r, c, n = line.split()
    r = int(r)
    c = int(c)
    n = int(n)
    if r == 0 and c == 0 and n == 0:
        break
    if r == 0:
        for i in range(c):
            input().split()
        print("Yes")
    else:
        ids = {}
        ids['s'] = 0
        students = 0
        stud_course_list = []
        course_cap = {}
        id = 0

        for i in range(r):
            student, course = input().split()
            stud_course_list.append([student, course])
            if student in ids:
                pass
            else:
                id += 1
                students += 1
                ids[student] = id

        for i in stud_course_list:
            course = i[1]
            if course in ids:
                pass
            else:
                id += 1
                ids[course] = id

        for i in range(c):
            course, cap = input().split()
            course_cap[course] = cap

        ids['t'] = id + 1
        g = []
        for i in range(id+2):
            row = []
            for j in range(id+2):
                row.append(0)
            g.append(row)

        source = 0
        sink = len(g) - 1

        for i in stud_course_list:
            id1 = ids[i[0]]
            id2 = ids[i[1]]
            g[id1][id2] = 1

        for i in range(students):
            g[source][i + 1] = n

        for i in range(c):
            g[students+i+1][sink] = c

        yes = students * n
        val = FordFulkerson(g, source, sink)
        if val == yes:
            print("Yes")
        else:
            print("No")
