"""
Andre Tan, akt6pfg
Homework 3
"""
import random
import time


def bruteforce(coords):
    shortest = 0
    for i in coords:
        for j in coords:
            length = ((((i[0] - j[0])**2) + ((i[1]-j[1])**2))**0.5)
            if length != 0 and length < shortest:
                shortest = length
            elif shortest == 0:
                shortest = length
    return shortest


def divideandconquer(coords):
    if len(coords) <= 3:
        return bruteforce(coords)
    midpoint = len(coords)//2
    leftlist = coords[:midpoint]
    rightlist = coords[midpoint:]
    leftval = divideandconquer(leftlist)
    rightval = divideandconquer(rightlist)
    d = min(leftval, rightval)
    strip = []
    for i in range(len(coords)):
        if abs(coords[i][0] - coords[midpoint][0] <= d):
            strip.append(coords[i])
    strip = sorted(coords, key=lambda p: p[1])
    min_dist = d
    for i in range(len(strip)):
        j = i + 1
        while j < len(strip) and dist(strip[i], strip[j]) < min_dist:
            min_dist = dist(strip[i], strip[j])
            j += 1
    return min_dist


def dist(i, j):
    distance = ((((i[0] - j[0])**2) + ((i[1]-j[1])**2))**0.5)
    return distance


def find(coords):
    sorted_list = sorted(coords, key=lambda p: p[0])
    return divideandconquer(sorted_list)


n = ''
while n != 0:
    n = int(input())

    coords = []

    for i in range(0, n):
        x, y = input().split()
        x = round(float(x), 2)
        y = round(float(y), 2)
        coord = [x, y]
        coords.append(coord)

    retval = find(coords)
    if retval > 10000:
        print("infinity")
    elif n != 0:
        print('{:.4f}'.format(retval))
