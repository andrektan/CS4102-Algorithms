import random


def insertionSort(list, start, end):
    for j in range(start, end+1):
        key = list[j]
        i = j - 1
        while i >= 0 and list[i] > key:
            list[i+1] = list[i]
            i -= 1
        list[i+1] = key

# Lomuto's partition


def partition(list, i, j):
    pivot_index = (int)(random.randrange(i, j))
    pivot = list[pivot_index]  # Pivot value
    list[pivot_index] = list[j]  # Swap last index value into new position
    list[j] = pivot  # Swap pivot value into last index
    y = i
    for x in range(i, j):
        if list[x] < pivot:
            (list[x], list[y]) = (list[y], list[x])
            y += 1
    (list[y], list[j]) = (list[j], list[y])
    return y


def quickSort(list, i, j, minSize):
    if i < j:
        q = partition(list, i, j)
        if j-i+1 >= minSize or minSize <= 1:
            quickSort(list, i, q-1, minSize)
            quickSort(list, q+1, j, minSize)
        elif minSize > 1 and j-i+1 < minSize:
            insertionSort(list, i, j)
    return
