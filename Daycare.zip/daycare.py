def T(R, Cr, Ct, trailer_size):
    for room in R:
        avail = Cr + Ct
        space_needed = room[0] - avail
        if space_needed < 0:
            space_needed = 0
        if room[0] <= room[1]:
            if space_needed > 0:
                Ct += space_needed
                trailer_size += space_needed
            Cr += room[1] - room[0]  # always positive
        elif room[0] > room[1]:
            if space_needed > 0:
                to_store = room[0]
                trailer_size += space_needed
                Ct += space_needed
                if Cr > 0:
                    if to_store > Cr:
                        to_store -= Cr
                        Cr = 0
                        Ct -= to_store
                    elif to_store <= Cr:
                        Cr -= to_store
                else:
                    Ct -= to_store
                Cr += room[1]
            else:
                trailer_size += space_needed
                Ct += space_needed
                to_store = room[0]
                if Cr > 0:
                    if to_store > Cr:
                        to_store -= Cr
                        Cr = 0
                        Ct -= to_store
                    elif to_store <= Cr:
                        Cr -= to_store
                else:
                    Ct -= to_store
                Cr += room[1]
                to_store = room[0]
            # Move from Ct to Cr
            to_move = trailer_size - Ct
            if Cr > 0:
                if Cr >= to_move:
                    Cr -= to_move
                    Ct += to_move
                elif Cr < to_move:
                    Ct += Cr
                    Cr = 0
    return trailer_size


while True:
    try:
        rooms = []
        count = 0
        n = input()
        n = int(n)
        for i in range(n):
            old_cap, new_cap = input().split()
            old_cap = int(old_cap)
            new_cap = int(new_cap)
            rooms.append([old_cap, new_cap])
        # Room size increases
        r1 = []
        # Room size stays the same
        r2 = []
        # Room size decreases
        r3 = []
        for room in rooms:
            if room[0] < room[1]:
                r1.append(room)
            elif room[0] == room[1]:
                r2.append(room)
            elif room[0] > room[1]:
                r3.append(room)
        r1.sort()
        r2.sort()
        r3.sort(key=lambda x: x[0], reverse=True)
        r3.sort(key=lambda x: x[0] - x[1])
        r3.sort(key=lambda x: x[0], reverse=True)
        r = r1 + r2 + r3
        print(T(r, 0, 0, 0))
    except EOFError:
        break
