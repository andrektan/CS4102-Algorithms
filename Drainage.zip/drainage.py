elevation_map = []
drain_map = []


def find_drain(col, row):
    current_elevation = elevation_map[row][col]
    if drain_map[row][col] == -1:
        if row != 0 and current_elevation < elevation_map[row-1][col]:
            up = find_drain(col, row-1)
        else:
            up = 0
        if row != len(elevation_map) - 1 and current_elevation < elevation_map[row+1][col]:
            down = find_drain(col, row+1)
        else:
            down = 0
        if col != 0 and current_elevation < elevation_map[row][col-1]:
            left = find_drain(col-1, row)
        else:
            left = 0
        if col != len(elevation_map[col]) - 1 and current_elevation < elevation_map[row][col+1]:
            right = find_drain(col+1, row)
        else:
            right = 0
        val = max(up, down, left, right)
        drain_map[row][col] = 1 + val
    return drain_map[row][col]


def longest_drain(grid, title, r, c):
    global elevation_map, drain_map
    elevation_map = grid
    drain_map = [[-1 for i in range(r)]
                 for j in range(c)]
    longest = -1
    for row in range(r):
        for col in range(c):
            longest = max(longest, find_drain(col, row))
    print(title + ": " + str(longest))
    return


n = int(input())
for i in range(n):
    title, r, c = input().split()
    r = int(r)
    c = int(c)
    grid = []
    for j in range(r):
        row = list(map(int, input().strip().split()))
        grid.append(row)
    longest_drain(grid, title, r, c)
